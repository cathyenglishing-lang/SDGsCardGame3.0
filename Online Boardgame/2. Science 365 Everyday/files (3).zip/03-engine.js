/* Science Every Day 365 — APPLICATION ENGINE
   Views, Bloom ladder, coach feedback, paths, search, studio, badges. */
/* ============================================================
   ENGINE
   ============================================================ */
const CAT={
 classic:{label:'Classic figure 經典人物',c:'#1F35B0',ico:'📜'},
 women:{label:'Women in science 女性科學家',c:'#E8558E',ico:'👩‍🔬'},
 asia:{label:'Asia & Taiwan 亞洲與臺灣',c:'#FF5D47',ico:'🌏'},
 modern:{label:'Contemporary 當代',c:'#2EA8E0',ico:'🛰️'},
 overlooked:{label:'Overlooked 被忽略',c:'#FF9F1C',ico:'🔦'},
 team:{label:'Team or institution 團隊',c:'#2FBE8F',ico:'🤝'},
 event:{label:'Event or discovery 事件',c:'#7B5CD6',ico:'📅'},
 ethics:{label:'Ethics case 倫理案例',c:'#171431',ico:'⚖️'}
};

const BLOOM=[
 {key:'remember',n:'1',name:'Remember',zh:'記憶',color:'#2EA8E0',pts:10},
 {key:'understand',n:'2',name:'Understand',zh:'理解',color:'#2FBE8F',pts:15},
 {key:'apply',n:'3',name:'Apply',zh:'應用',color:'#FFC53D',pts:20},
 {key:'analyze',n:'4',name:'Analyze',zh:'分析',color:'#FF9F1C',pts:25},
 {key:'evaluate',n:'5',name:'Evaluate',zh:'評鑑',color:'#FF5D47',pts:35},
 {key:'create',n:'6',name:'Create',zh:'創造',color:'#7B5CD6',pts:50}
];

/* build the 365 entries */
const DAYS=[];
for(let m=1;m<=12;m++){
  (R[m]||[]).forEach((row,i)=>{
    const p=row.split('|');
    const key=m+'-'+(i+1);
    const d=DEEP[key]||{};
    DAYS.push({
      m, d:i+1, key,
      name:p[0], zh:p[1], country:p[2], years:p[3], field:p[4], cat:p[5], disc:p[6],
      deep:!!DEEP[key],
      kw:d.kw, story:d.story, quote:d.quote, life:d.life, bloom:d.bloom
    });
  });
}
const byKey=k=>DAYS.find(x=>x.key===k);
const TOTAL=DAYS.length;   // 365 + one leap-day bonus card
document.getElementById('collTot').textContent=TOTAL;

/* monogram from name */
function mono(e){
  if(CAT[e.cat].ico && (e.cat==='team'||e.cat==='event'||e.cat==='ethics')) return CAT[e.cat].ico;
  const w=e.name.replace(/[^A-Za-z '’-]/g,'').trim().split(/\s+/).filter(Boolean);
  if(!w.length) return '★';
  if(w.length===1) return w[0].slice(0,2).toUpperCase();
  return (w[0][0]+w[w.length-1][0]).toUpperCase();
}

/* ============ STATE ============ */
const TODAY={m:7,d:24};
const state={
  points:0, view:'year', month:TODAY.m, curKey:null, level:'B1',
  progress:{},        // key -> {bloomKey:val}
  cards:new Set(),
  evals:0, creates:0,
  earned:new Set(),
  authored:{}         // key -> {A2,B1,B2} written in the Studio
};

const $=s=>document.querySelector(s);
const stage=$('#stage');
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');
  clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove('show'),2300);}
function addPoints(p){state.points+=p;$('#ptsVal').textContent=state.points;}
function confetti(color){
  const cs=[color||'#FFC53D','#2FBE8F','#FF5D47','#2EA8E0','#7B5CD6'];
  for(let i=0;i<40;i++){const c=document.createElement('div');c.className='confetti';
    c.style.left=Math.random()*100+'vw';c.style.background=cs[i%cs.length];
    c.style.animationDuration=(1.6+Math.random()*1.3)+'s';
    document.body.appendChild(c);setTimeout(()=>c.remove(),3200);}
}
const doneCount=k=>Object.keys(state.progress[k]||{}).length;

/* ============ AUTO SCAFFOLD ============ */
function autoStory(e){
  return {
   A2:`${e.name} — ${e.zh}. From ${e.country.replace(/^\S+\s/,'')}, ${e.years}. Field: ${e.field}. In simple words: ${e.disc.toLowerCase()}. Read the card, then try the tasks below. ✍️ This card is waiting for a full A2 story — write one in the Studio.`,
   B1:`${e.name} (${e.zh}) worked in ${e.field.toLowerCase()} — ${e.country.replace(/^\S+\s/,'')}, ${e.years}. ${e.disc}. This entry currently shows the verified summary only; the full B1 narrative has not been written yet. Use the Studio to draft it, or write it yourself as a science-communication task.`,
   B2:`${e.name} (${e.zh}), ${e.country.replace(/^\S+\s/,'')}, ${e.years}, ${e.field}. ${e.disc}. This is a roster entry rather than an authored card. A complete B2 version would add historical context, name the collaborators and institutions involved, and identify at least one contested or overlooked aspect of the story — exactly the kind of writing this platform asks students to produce.`
  };
}
/* Remember MCQ built from real roster data — distractors are other people's real contributions */
function autoRemember(e){
  const pool=DAYS.filter(x=>x.key!==e.key&&x.cat===e.cat);
  const src=pool.length>=3?pool:DAYS.filter(x=>x.key!==e.key);
  const picks=[];const used=new Set();
  while(picks.length<3&&picks.length<src.length){
    const c=src[Math.floor(Math.random()*src.length)];
    if(used.has(c.key))continue;used.add(c.key);
    picks.push(c.disc.length>90?c.disc.slice(0,88)+'…':c.disc);
  }
  const correct=e.disc.length>90?e.disc.slice(0,88)+'…':e.disc;
  const opts=[correct,...picks];
  for(let i=opts.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[opts[i],opts[j]]=[opts[j],opts[i]];}
  return {q:`Which contribution belongs to ${e.name}?`,opts,correct:opts.indexOf(correct)};
}
function autoBloom(e){
  const n=e.name;
  return {
   remember:autoRemember(e),
   understand:{q:`In your own words, explain what ${n} contributed — as if to a 10-year-old who has never heard the name.`,
     starter:'Avoid technical words. One clear sentence beats three vague ones.'},
   apply:{q:`Where might you meet this work in everyday life, at home, on campus, or in Taiwan? Give one concrete example.`,
     starter:'Be specific: name an object, a place, or a moment in your day.'},
   analyze:{q:`Compare this card with one you have already collected. What do the two have in common, and where do they differ — in method, in era, or in who received the credit?`,
     starter:'Try: "Both … , but whereas X … , Y … ."'},
   evaluate:{q:`Judge the significance of this contribution. Take a stance and defend it with a reason in 1–3 English sentences.`,
     stances:['Major impact','Moderate impact','Overrated'],starter:'I would rate this as ___ because…'},
   create:{q:`Create a 30-second spoken introduction to ${n} for a general audience. Open with a hook, not a date.`,
     starter:'Hooks work: a question, a surprising image, or "Imagine a world without…"'}
  };
}
const getStory=e=>state.authored[e.key]||e.story||autoStory(e);
const getBloom=e=>e.bloom||(e._ab||(e._ab=autoBloom(e)));
const getKw=e=>e.kw||[[e.field,''],[e.country.replace(/^\S+\s/,''),''],[e.years,'']];

/* ============ VIEWS ============ */
function setView(v){
  state.view=v;
  document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('on',t.dataset.v===v));
  if(v==='year')viewYear();
  else if(v==='today')openDay(TODAY.m+'-'+TODAY.d);
  else if(v==='paths')viewPaths();
  else if(v==='search')viewSearch();
  else if(v==='studio')viewStudio();
  window.scrollTo({top:0,behavior:'smooth'});
}

function viewYear(){
  const total=state.cards.size;
  stage.innerHTML=`
   <div class="sec-head"><h2>📅 A Year of Scientific Minds</h2>
   <p>365 days + a leap-day bonus · 12 themed months · every month mixes classic figures with women, Asian, overlooked and collective stories 每月皆混合不同類型人物</p></div>
   <div class="year-grid">${MONTHS.map((mo,i)=>{
     const m=i+1;const days=DAYS.filter(x=>x.m===m);
     const done=days.filter(x=>state.cards.has(x.key)).length;
     return `<button class="month-tile" data-m="${m}">
       <div class="mt-band" style="background:${mo.c}">
         <div class="mt-num">MONTH ${String(m).padStart(2,'0')}</div>
         <div class="mt-name">${mo.n}</div>
         <div class="mt-theme">${mo.theme}</div>
       </div>
       <div class="mt-body">
         <div class="mt-zh">${mo.zh}｜${mo.tz}</div>
         <div class="mini-bar"><div class="mini-fill" style="width:${done/days.length*100}%"></div></div>
         <div class="mt-count">${done} / ${days.length} collected</div>
       </div></button>`;}).join('')}
   </div>
   <div class="sec-head"><h2>📊 Your year so far</h2></div>
   <div class="day-progress">
     <div class="prog-txt">${total} / ${TOTAL}</div>
     <div class="prog-bar"><div class="prog-fill" style="width:${total/TOTAL*100}%"></div></div>
     <div class="collect-note">⭐ ${state.points} points · ⚖️ ${state.evals} judgements · ✍️ ${state.creates} creations · 🏅 ${state.earned.size} badges</div>
   </div>`;
  stage.querySelectorAll('.month-tile').forEach(b=>b.onclick=()=>viewMonth(+b.dataset.m));
}

function viewMonth(m){
  state.month=m;state.view='month';
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('on'));
  const mo=MONTHS[m-1];const days=DAYS.filter(x=>x.m===m);
  const done=days.filter(x=>state.cards.has(x.key)).length;
  /* first-of-month weekday offset, purely visual, using a 2026 non-leap layout */
  const offs=[3,6,6,2,4,0,2,5,1,3,6,1];
  const off=offs[m-1];
  let cells='';
  for(let i=0;i<off;i++)cells+=`<div class="dcell blank"></div>`;
  days.forEach(e=>{
    const isDone=state.cards.has(e.key);
    const isToday=(e.m===TODAY.m&&e.d===TODAY.d);
    cells+=`<button class="dcell${isDone?' done':''}${isToday?' today':''}" data-k="${e.key}" title="${esc(e.name)}">
      <span class="cdot" style="background:${CAT[e.cat].c}"></span>
      <div class="dn">${e.d}</div>
      <div class="dnm">${esc(e.name)}</div></button>`;
  });
  stage.innerHTML=`
   <div class="month-head">
     <div class="mh-l"><h2>${mo.n} ${mo.zh} · ${mo.theme}</h2>
     <p>${mo.tz} · ${done}/${days.length} collected</p></div>
     <div class="mh-nav">
       <button class="nav-btn ghost" id="pm">← Prev</button>
       <button class="nav-btn ghost" id="yr">All months</button>
       <button class="nav-btn" id="nm">Next →</button>
     </div>
   </div>
   <div class="dow-row">${['S','M','T','W','T','F','S'].map(d=>`<div class="dow">${d}</div>`).join('')}</div>
   <div class="day-grid">${cells}</div>`;
  $('#pm').onclick=()=>viewMonth(m===1?12:m-1);
  $('#nm').onclick=()=>viewMonth(m===12?1:m+1);
  $('#yr').onclick=()=>setView('year');
  stage.querySelectorAll('.dcell[data-k]').forEach(b=>b.onclick=()=>openDay(b.dataset.k));
  window.scrollTo({top:0,behavior:'smooth'});
}

/* ============ DAY ============ */
function openDay(key){
  const e=byKey(key);if(!e)return;
  state.curKey=key;state.view='day';
  state.progress[key]=state.progress[key]||{};
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('on'));
  const st=getStory(e), cat=CAT[e.cat], isAuto=!e.deep&&!state.authored[key];
  const mo=MONTHS[e.m-1];

  stage.innerHTML=`
   <div class="back-row">
     <button class="btn-main ghost" id="bk">← ${mo.n} ${mo.zh}</button>
     <button class="btn-main ghost" id="bkY">📅 All months</button>
   </div>
   <article class="sci-card">
     <div class="sci-band" style="background:${cat.c}">
       <span class="daytag">${mo.n.slice(0,3).toUpperCase()} ${e.d}</span>
       <div class="sci-top">
         <div class="monogram">${mono(e)}</div>
         <div><div class="sci-name">${esc(e.name)}</div><div class="sci-zh">${esc(e.zh)}</div></div>
       </div>
       <div class="sci-meta">
         <span class="tag">${esc(e.country)}</span><span class="tag">${esc(e.years)}</span>
         <span class="tag">${esc(e.field)}</span><span class="tag">${cat.ico} ${cat.label}</span>
       </div>
     </div>
     <div class="sci-body">
       <span class="block-label">🔎 Contribution 貢獻</span>
       <div class="discovery">${esc(e.disc)}</div>
       ${isAuto?`<div class="draft-note">✍️<div><b>Roster entry — story not yet written</b>
         The facts above are curated; the A2/B1/B2 narrative below is a placeholder. Writing it is the task.
         Open the <b>Studio</b> to author this card, or set it as a student assignment.</div></div>`:''}
       <div class="lvl-row"><span class="hint">Reading level 閱讀程度:</span>
         <div class="lvl-toggle" id="lvl">${['A2','B1','B2'].map(l=>`<button data-l="${l}" class="${l===state.level?'on':''}">${l}</button>`).join('')}</div>
       </div>
       <p class="story" id="storyTxt">${esc(st[state.level])}</p>
       <div class="kw-row">${getKw(e).map(k=>`<span class="kw">${esc(k[0])}${k[1]?' <span>'+esc(k[1])+'</span>':''}</span>`).join('')}</div>
       ${e.quote?`<div class="quote"><p>"${esc(e.quote.text)}"</p>
         <span class="q-tag ${e.quote.tag}">${esc(e.quote.tagLabel)}</span></div>`:''}
       ${e.life?`<span class="block-label">🔗 Science in life 生活連結</span><div class="life">${esc(e.life)}</div>`:''}
     </div>
   </article>
   <div class="sec-head"><h2>🪜 Climb the Bloom Ladder</h2>
     <p>Six levels · finish any 3 to collect this card · levels 5 &amp; 6 are never auto-graded</p></div>
   <div class="bloom" id="bl"></div>
   <div class="day-progress">
     <div class="prog-txt"><span id="pn">0</span>/6</div>
     <div class="prog-bar"><div class="prog-fill" id="pf"></div></div>
     <div class="collect-note">💡 The coach nudges, it does not score. You revise, then a partner or teacher responds. 教師與同儕才是評分者。</div>
   </div>`;
  $('#bk').onclick=()=>viewMonth(e.m);
  $('#bkY').onclick=()=>setView('year');
  $('#lvl').onclick=ev=>{const b=ev.target.closest('button');if(!b)return;
    state.level=b.dataset.l;
    $('#lvl').querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b));
    $('#storyTxt').textContent=getStory(e)[state.level];};
  renderBloom(e);updateProg(e);
  window.scrollTo({top:0,behavior:'smooth'});
}

function renderBloom(e){
  const bl=$('#bl');if(!bl)return;bl.innerHTML='';
  const B=getBloom(e);
  BLOOM.forEach(b=>{
    const done=!!state.progress[e.key][b.key];
    const isMcq=!!(B[b.key]&&B[b.key].opts);
    const row=document.createElement('div');
    row.className='b-row'+(done?' done':'');
    row.innerHTML=`<div class="b-head">
      <div class="b-num" style="background:${b.color}">${b.n}</div>
      <div class="b-info"><div class="b-name">${b.name}<span class="zh">${b.zh}</span></div>
        <div class="b-pts">+${b.pts} pts · ${isMcq?'quick check':'open response'}</div></div>
      <div class="b-state ${done?'':'arrow'}">${done?'✅':'▾'}</div></div>
      <div class="b-panel" id="p-${b.key}"></div>`;
    bl.appendChild(row);
    row.querySelector('.b-head').onclick=()=>{
      const was=row.classList.contains('open');
      bl.querySelectorAll('.b-row').forEach(r=>r.classList.remove('open'));
      if(!was){row.classList.add('open');buildPanel(e,b);}
    };
  });
}

function buildPanel(e,b){
  const p=$('#p-'+b.key);if(!p||p.dataset.built)return;p.dataset.built='1';
  const data=getBloom(e)[b.key];
  const saved=state.progress[e.key][b.key];

  if(data.opts){
    p.innerHTML=`<p class="b-q">${esc(data.q)}</p><div class="opts"></div>`;
    const box=p.querySelector('.opts');
    data.opts.forEach((t,i)=>{
      const btn=document.createElement('button');
      btn.className='opt';btn.textContent=t;btn.disabled=!!saved;
      if(saved&&i===data.correct)btn.classList.add('right');
      btn.onclick=()=>{
        if(state.progress[e.key][b.key])return;
        if(i===data.correct){btn.classList.add('right');
          box.querySelectorAll('.opt').forEach(o=>o.disabled=true);mark(e,b,true);}
        else{btn.classList.add('wrong');btn.disabled=true;toast('Not quite — try another 再試一次');}
      };
      box.appendChild(btn);
    });
    return;
  }

  const stancesHTML=data.stances?`<div class="stances" id="s-${b.key}">${
    data.stances.map(s=>`<button class="stance" data-s="${esc(s)}">${esc(s)}</button>`).join('')}</div>`:'';
  p.innerHTML=`<p class="b-q">${esc(data.q)}</p>${stancesHTML}
    <p class="starter">✏️ ${esc(data.starter||'Write in full sentences.')}</p>
    <textarea id="t-${b.key}" placeholder="Write your response in English…" ${saved?'disabled':''}>${saved?esc(saved.text||''):''}</textarea>
    <div class="submit-row">
      <button class="btn-main mint" id="sb-${b.key}" ${saved?'disabled':''}>${saved?'✓ Submitted':'Get coach feedback →'}</button>
      <span class="wc" id="w-${b.key}">0 words</span></div>
    <div class="feedback ${saved?'show':''}" id="f-${b.key}">${saved?saved.fb||'':''}</div>`;

  let stance=null;
  if(data.stances){p.querySelector('#s-'+b.key).onclick=ev=>{
    const btn=ev.target.closest('.stance');if(!btn||saved)return;stance=btn.dataset.s;
    p.querySelectorAll('.stance').forEach(x=>x.classList.toggle('on',x===btn));};}
  const ta=p.querySelector('#t-'+b.key),wc=p.querySelector('#w-'+b.key);
  ta.oninput=()=>{const n=ta.value.trim()?ta.value.trim().split(/\s+/).length:0;
    wc.textContent=n+' word'+(n===1?'':'s');};
  p.querySelector('#sb-'+b.key).onclick=()=>{
    if(state.progress[e.key][b.key])return;
    const text=ta.value.trim(),words=text?text.split(/\s+/).length:0;
    if(data.stances&&!stance){toast('Pick a stance first 先選立場');return;}
    if(words<6){toast('Write at least 6 words ✍️');return;}
    const fb=coach(b.key,text,words);
    const fbx=p.querySelector('#f-'+b.key);fbx.innerHTML=fb;fbx.classList.add('show');
    ta.disabled=true;const sb=p.querySelector('#sb-'+b.key);sb.textContent='✓ Submitted';sb.disabled=true;
    if(b.key==='evaluate')state.evals++;
    if(b.key==='create')state.creates++;
    mark(e,b,true,{text,fb});
  };
}

/* coach: scaffolds language, never assigns a score */
function coach(key,text,words){
  const l=text.toLowerCase();
  const reason=/because|since|so that|as a result|therefore|due to|which means/.test(l);
  const example=/example|for instance|such as|like when|imagine|in taiwan|every time/.test(l);
  const hedge=/however|although|on the other hand|but |while /.test(l);
  let a,b;
  if(key==='evaluate'){
    a=reason?'You supported your stance with a reason — that is the core move of an Evaluate task.'
            :'Add the word <b>because</b> and give one reason for the stance you chose.';
    b=hedge?'You also acknowledged another side, which strengthens the judgement.'
           :'Now add one clause beginning <b>Although…</b> or <b>However…</b> to show you considered the other side.';
  }else if(key==='create'){
    a=example?'Good — you used something concrete, which is what makes science communication land.'
             :'Add one concrete image or example a listener can picture.';
    b=words<25?'Expand to 2–3 full sentences so the idea has room to breathe.'
              :'Good length. Read it aloud — does it sound like speech, or like a textbook?';
  }else if(key==='analyze'){
    a=/both|whereas|while|differ|similar|unlike/.test(l)?'You used comparison language — exactly right for Analyze.'
      :'Use explicit comparison signals: <b>Both… but whereas… </b>';
    b='Push further: name <b>one difference in method or era</b>, not only in topic.';
  }else if(key==='apply'){
    a=example?'You named something concrete — that is what Apply asks for.'
             :'Name a specific object, place or moment rather than a general area.';
    b='Add a second sentence explaining <b>how</b> the connection actually works.';
  }else{
    a=words<15?'Try one more sentence — a 10-year-old needs a little more.'
              :'Reasonable length for a simple explanation.';
    b=/[A-Z][a-z]+ology|physics|chemistry|molecul|quantum/.test(text)
      ?'Check for jargon: could you swap the technical word for an everyday one?'
      :'Nice plain language. Now check: is every sentence something a child could picture?';
  }
  return `<b>Coach:</b> ${a}<br>👉 ${b}<br><span style="color:#4A4763">No score is given here. Revise it, then take it to a partner or your teacher.</span>`;
}

function mark(e,b,ok,extra){
  state.progress[e.key][b.key]=extra||true;
  addPoints(b.pts);
  /* update this row in place — re-rendering would collapse the open panel
     and destroy the coach feedback the moment it appeared */
  const bl=$('#bl'), idx=BLOOM.findIndex(x=>x.key===b.key), row=bl&&bl.children[idx];
  if(row){
    row.classList.add('done');
    const st=row.querySelector('.b-state');
    st.textContent='✅'; st.classList.remove('arrow');
  }
  updateProg(e);
  toast(`✅ ${b.name} complete +${b.pts} pts`);
}
function updateProg(e){
  const n=doneCount(e.key),f=$('#pf'),t=$('#pn');
  if(f){f.style.width=(n/6*100)+'%';t.textContent=n;}
  if(n>=3&&!state.cards.has(e.key))collect(e);
}
function collect(e){
  state.cards.add(e.key);
  $('#collCount').textContent=state.cards.size;
  $('#streakVal').textContent=state.cards.size;
  confetti(CAT[e.cat].c);
  toast(`🃏 Collected ${e.name}!`);
  checkBadges();
}

/* ============ PATHS ============ */
const PATHS=[
 {id:'women',ico:'👩‍🔬',t:'Women in Science',zh:'女性科學家',c:'#E8558E',
  d:'Deliberately spread across all twelve months rather than confined to one — because segregating them into a single month is part of the problem.',f:e=>e.cat==='women'},
 {id:'overlooked',ico:'🔦',t:'The Overlooked',zh:'被忽略的人',c:'#FF9F1C',
  d:'People whose work was essential and whose names were not on the prize. The best entry point for discussing how credit works.',f:e=>e.cat==='overlooked'},
 {id:'asia',ico:'🌏',t:'Asia & Taiwan',zh:'亞洲與臺灣',c:'#FF5D47',
  d:'Local and regional science, from Zhang Heng to the chip ecosystem — the strand that makes this platform yours.',f:e=>e.cat==='asia'},
 {id:'ethics',ico:'⚖️',t:'Ethics & Judgement',zh:'倫理與判斷',c:'#171431',
  d:'Consent, credit, weapons, bias, risk. Every card here is built for the Evaluate level.',f:e=>e.cat==='ethics'},
 {id:'team',ico:'🤝',t:'It Took a Team',zh:'這是團隊的事',c:'#2FBE8F',
  d:'The direct antidote to the lone-genius myth: collaborations, institutions and collectives.',f:e=>e.cat==='team'},
 {id:'modern',ico:'🛰️',t:'Living Scientists',zh:'當代科學家',c:'#2EA8E0',
  d:'Researchers working now. Useful when students say science already finished.',f:e=>e.cat==='modern'},
 {id:'event',ico:'📅',t:'Moments & Discoveries',zh:'關鍵時刻',c:'#7B5CD6',
  d:'Events rather than people — treaties, missions, outbreaks and turning points.',f:e=>e.cat==='event'},
 {id:'classic',ico:'📜',t:'The Canon',zh:'經典人物',c:'#1F35B0',
  d:'The names most curricula already include — best read alongside the Overlooked path.',f:e=>e.cat==='classic'},
 {id:'deep',ico:'⭐',t:'Fully Authored Cards',zh:'完整撰寫的卡片',c:'#FFC53D',
  d:'Days with hand-written A2/B1/B2 stories and custom Bloom questions. Start here to see the target quality.',f:e=>e.deep}
];

function viewPaths(){
  stage.innerHTML=`<div class="sec-head"><h2>🧭 Learning Paths</h2>
    <p>Cross-cutting collections that run through the whole year, so a theme can be taught in one week or followed all year 主題可貫穿全年，也可濃縮為單週課程</p></div>
    <div class="path-grid">${PATHS.map(p=>{
      const days=DAYS.filter(p.f);const got=days.filter(d=>state.cards.has(d.key)).length;
      return `<button class="path" data-p="${p.id}">
        <div class="path-band" style="background:${p.c}"><div class="path-ico">${p.ico}</div>
          <div><div class="pt">${p.t}</div><div class="pz">${p.zh} · ${days.length} days</div></div></div>
        <div class="path-body"><p>${p.d}</p>
          <div class="mini-bar"><div class="mini-fill" style="width:${got/days.length*100}%"></div></div>
          <div class="mt-count">${got} / ${days.length} collected</div></div></button>`;}).join('')}
    </div>`;
  stage.querySelectorAll('.path').forEach(b=>b.onclick=()=>viewPath(b.dataset.p));
}
function viewPath(id){
  const p=PATHS.find(x=>x.id===id),days=DAYS.filter(p.f);
  stage.innerHTML=`<div class="month-head"><div class="mh-l"><h2>${p.ico} ${p.t}</h2>
    <p>${p.zh} · ${days.length} cards across the year</p></div>
    <div class="mh-nav"><button class="nav-btn ghost" id="bp">← All paths</button></div></div>
    <div class="list">${days.map(e=>listItem(e)).join('')}</div>`;
  $('#bp').onclick=()=>viewPaths();
  bindList();
  window.scrollTo({top:0,behavior:'smooth'});
}
function listItem(e){
  return `<button class="li" data-k="${e.key}">
    <div class="li-date"><div class="m">${MONTHS[e.m-1].n.slice(0,3).toUpperCase()}</div><div class="d">${e.d}</div></div>
    <div class="li-main"><div class="n">${esc(e.name)}${e.deep?' ⭐':''}</div>
      <div class="s">${esc(e.zh)} · ${esc(e.field)} · ${esc(e.country)}</div></div>
    <div class="li-chk">${state.cards.has(e.key)?'✅':'○'}</div></button>`;
}
function bindList(){stage.querySelectorAll('.li[data-k]').forEach(b=>b.onclick=()=>openDay(b.dataset.k));}

/* ============ SEARCH ============ */
function viewSearch(){
  stage.innerHTML=`<div class="sec-head"><h2>🔍 Find a scientist</h2>
    <p>Search all 365 by name, field, country or Chinese name 可用姓名、領域、國家或中文檢索</p></div>
    <div class="month-head"><input type="text" id="q" placeholder="e.g. Taiwan, genetics, 女性, Curie, ethics…" autocomplete="off"></div>
    <div class="list" id="res"></div>`;
  const q=$('#q'),res=$('#res');
  const run=()=>{
    const v=q.value.trim().toLowerCase();
    if(!v){res.innerHTML=`<div class="draft-note" style="background:var(--paper)">🔎<div>Type anything above. Try <b>Taiwan</b>, <b>overlooked</b>, <b>vaccine</b>, or a Chinese name.</div></div>`;return;}
    const hits=DAYS.filter(e=>(e.name+e.zh+e.field+e.country+e.disc+e.cat).toLowerCase().includes(v)).slice(0,60);
    res.innerHTML=hits.length?hits.map(listItem).join('')
      :`<div class="draft-note" style="background:var(--paper)">😕<div>No match for "<b>${esc(q.value)}</b>". Try a broader word — a field, a country, or a category like <b>ethics</b>.</div></div>`;
    bindList();
  };
  q.oninput=run;run();q.focus();
}

/* ============ STUDIO ============ */
function viewStudio(){
  const unwritten=DAYS.filter(e=>!e.deep&&!state.authored[e.key]).length;
  stage.innerHTML=`<div class="sec-head"><h2>✍️ Authoring Studio</h2>
    <p>${TOTAL-unwritten} of ${TOTAL} cards have full stories. Writing the rest is the curriculum, not the obstacle — this is where students become the authors. 學生撰寫卡片本身就是科學傳播任務。</p></div>
    <div class="month-head" style="display:block">
      <div class="field"><label>Pick a day 選擇日期</label>
        <select id="pick" style="width:100%;border:3px solid var(--ink);border-radius:12px;padding:9px 12px;font-family:var(--body);font-size:14.5px;background:var(--paper)"></select>
        <div class="help">Days already written show ⭐. Anything you write here appears immediately on that day's card.</div></div>
      <div class="field"><label>A2 story — 80–100 words, short sentences</label>
        <textarea id="a2" placeholder="Simple present, everyday vocabulary, one idea per sentence…"></textarea></div>
      <div class="field"><label>B1 story — 120–150 words, add cause and effect</label>
        <textarea id="b1" placeholder="Explain why it mattered, and connect the discovery to a consequence…"></textarea></div>
      <div class="field"><label>B2 story — 180–220 words, add context and contest</label>
        <textarea id="b2" placeholder="Add historical context, name collaborators, and identify what is disputed or overlooked…"></textarea></div>
      <div class="submit-row">
        <button class="btn-main mint" id="save">Save to this day</button>
        <button class="btn-main sky" id="draft">Load roster facts as a starting draft</button>
        <button class="btn-main ghost" id="exp">Export all as JSON</button>
      </div>
    </div>
    <div id="expOut"></div>
    <div class="sec-head"><h2>📋 Writing checklist</h2>
      <p>The house style for every card — worth giving to students as the rubric</p></div>
    <div class="month-head" style="display:block">
      <div style="font-size:14px;line-height:1.9">
      ✅ <b>No lone geniuses.</b> Name at least one collaborator, predecessor, or institution.<br>
      ✅ <b>Say who was overlooked</b>, if anyone was, and say it plainly.<br>
      ✅ <b>One life connection</b> a student could point at today.<br>
      ✅ <b>Tag every quote</b> as verified, attributed, or paraphrased — never guess.<br>
      ✅ <b>Social conditions matter.</b> What made this discovery possible at that time and place?<br>
      ✅ <b>A2 is not baby language.</b> Short sentences, real content.
      </div>
    </div>`;
  const sel=$('#pick');
  sel.innerHTML=DAYS.map(e=>`<option value="${e.key}">${MONTHS[e.m-1].n.slice(0,3)} ${e.d} — ${e.name}${(e.deep||state.authored[e.key])?' ⭐':''}</option>`).join('');
  sel.value=state.curKey||(TODAY.m+'-'+TODAY.d);
  const load=()=>{const e=byKey(sel.value);const s=state.authored[e.key]||e.story||{A2:'',B1:'',B2:''};
    $('#a2').value=s.A2||'';$('#b1').value=s.B1||'';$('#b2').value=s.B2||'';};
  sel.onchange=load;load();
  $('#draft').onclick=()=>{const e=byKey(sel.value),a=autoStory(e);
    $('#a2').value=`${e.name} (${e.zh}) — ${e.country}, ${e.years}. ${e.disc}`;
    $('#b1').value=`${e.disc} `;$('#b2').value=`${e.disc} `;
    toast('Facts loaded — now write it properly ✍️');};
  $('#save').onclick=()=>{
    const e=byKey(sel.value);
    const A2=$('#a2').value.trim(),B1=$('#b1').value.trim(),B2=$('#b2').value.trim();
    if(!A2||!B1||!B2){toast('All three levels are needed 三個程度都要填');return;}
    state.authored[e.key]={A2,B1,B2};
    addPoints(60);confetti('#FFC53D');
    toast(`✍️ ${e.name} authored! +60 pts`);
    checkBadges();
    sel.innerHTML=DAYS.map(x=>`<option value="${x.key}">${MONTHS[x.m-1].n.slice(0,3)} ${x.d} — ${x.name}${(x.deep||state.authored[x.key])?' ⭐':''}</option>`).join('');
    sel.value=e.key;
  };
  $('#exp').onclick=()=>{
    const out=Object.keys(state.authored).map(k=>{const e=byKey(k);
      return {day:`${MONTHS[e.m-1].n} ${e.d}`,name:e.name,zh:e.zh,story:state.authored[k]};});
    $('#expOut').innerHTML=out.length
      ?`<pre class="out">${esc(JSON.stringify(out,null,1))}</pre>`
      :`<div class="draft-note" style="background:var(--paper)">📭<div>Nothing authored in this session yet. Write a card above, then export.</div></div>`;
  };
}

/* ============ BADGES & COLLECTION ============ */
const BADGES=[
 {id:'first',ico:'🌱',t:'First Card',d:'Collect any one card',f:s=>s.cards.size>=1},
 {id:'ten',ico:'🔟',t:'Ten Minds',d:'Collect 10 cards',f:s=>s.cards.size>=10},
 {id:'month',ico:'🗓️',t:'Month Complete',d:'Collect every card in one month',
   f:s=>MONTHS.some((m,i)=>{const d=DAYS.filter(x=>x.m===i+1);return d.every(x=>s.cards.has(x.key));})},
 {id:'women',ico:'👩‍🔬',t:'Hidden Figures',d:'Collect 5 women-in-science cards',
   f:s=>DAYS.filter(e=>e.cat==='women'&&s.cards.has(e.key)).length>=5},
 {id:'taiwan',ico:'🏝️',t:'Taiwan Focus',d:'Collect 5 Asia & Taiwan cards',
   f:s=>DAYS.filter(e=>e.cat==='asia'&&s.cards.has(e.key)).length>=5},
 {id:'overlooked',ico:'🔦',t:'Credit Where Due',d:'Collect 5 overlooked-figure cards',
   f:s=>DAYS.filter(e=>e.cat==='overlooked'&&s.cards.has(e.key)).length>=5},
 {id:'ethics',ico:'⚖️',t:'Critical Thinker',d:'Submit 10 Evaluate responses',f:s=>s.evals>=10},
 {id:'creator',ico:'✍️',t:'Science Communicator',d:'Submit 10 Create responses',f:s=>s.creates>=10},
 {id:'author',ico:'📝',t:'Card Author',d:'Write a full card in the Studio',f:s=>Object.keys(s.authored).length>=1},
 {id:'author5',ico:'📚',t:'Staff Writer',d:'Author 5 cards',f:s=>Object.keys(s.authored).length>=5},
 {id:'world',ico:'🌍',t:'Around the World',d:'Collect cards from 15 countries',f:s=>countries().got>=15},
 {id:'year',ico:'🏆',t:'A Full Year',d:'Collect every card in the year',f:s=>s.cards.size>=TOTAL}
];
function checkBadges(){
  BADGES.forEach(b=>{if(!state.earned.has(b.id)&&b.f(state)){
    state.earned.add(b.id);setTimeout(()=>toast(`🏅 Badge unlocked: ${b.t}`),700);}});
}
function countries(){
  const all=new Map();
  DAYS.forEach(e=>{const f=e.country.split(' ')[0];
    if(!all.has(f))all.set(f,{flag:f,name:e.country.replace(/^\S+\s/,''),n:0,got:0});
    all.get(f).n++;if(state.cards.has(e.key))all.get(f).got++;});
  const list=[...all.values()].sort((a,b)=>b.n-a.n);
  return {list,got:list.filter(x=>x.got>0).length,total:list.length};
}
function openCollection(){
  const c=countries();
  $('#ovBody').innerHTML=`<button class="close-x" id="cx">✕ Close</button>
    <h2>🃏 Collection</h2>
    <p class="sub">${state.cards.size} of 365 cards · ${c.got} of ${c.total} places · ${state.earned.size} of ${BADGES.length} badges</p>
    <h3>🌍 World Map 世界地圖</h3><p class="sub">Places light up as you collect cards from them</p>
    <div class="world">${c.list.map(x=>`<div class="wc-item${x.got?'':' dim'}">
      <div class="f">${x.flag}</div><div class="n">${esc(x.name)}</div>
      <div class="c">${x.got}/${x.n}</div></div>`).join('')}</div>
    <h3>🏅 Badges 徽章</h3><p class="sub">Earned through consistency, curiosity, judgement and creation</p>
    <div class="badge-grid">${BADGES.map(b=>`<div class="badge${state.earned.has(b.id)?'':' locked'}">
      <div class="b-ico">${b.ico}</div><div><div class="b-t">${b.t}</div><div class="b-d">${b.d}</div></div></div>`).join('')}</div>`;
  $('#ov').classList.add('show');
  $('#cx').onclick=()=>$('#ov').classList.remove('show');
}

/* ============ WIRING ============ */
document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>setView(t.dataset.v));
$('#collBtn').onclick=openCollection;
$('#brandHome').onclick=()=>setView('year');
$('#ov').onclick=e=>{if(e.target.id==='ov')$('#ov').classList.remove('show');};
document.addEventListener('keydown',e=>{if(e.key==='Escape')$('#ov').classList.remove('show');});

setView('year');
toast(`Today is ${MONTHS[TODAY.m-1].n} ${TODAY.d} — tap ⭐ Today to begin`);
