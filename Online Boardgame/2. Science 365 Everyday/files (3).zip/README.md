# Science Every Day 365 · 每日科學人

A daily science-communication learning platform: 366 curated cards (365 days + a
leap-day bonus), each with a CEFR-levelled story and a six-level Bloom's Taxonomy
ladder, built for ESP / EAP / EMI and science communication teaching.

---

## Quick start

**Just want to use it?** Open `dist/science-every-day-365.html` in any browser.
One file, no server, no install. Works offline (fonts load from the internet if
available, and it degrades gracefully if not).

**Want to edit it?** Edit the files in `js/` and `css/`, open `index.html` to
test, then run `python3 build.py` to regenerate the standalone version.

---

## Project structure

```
science-every-day-365/
├── index.html              development version (loads external files)
├── build.py                bundles everything into dist/
├── README.md               this file
├── css/
│   └── styles.css          all styling and the design tokens
├── js/
│   ├── 00-config.js        the 12 month themes, names, colours
│   ├── 01-roster.js        ★ THE ROSTER — all 366 entries
│   ├── 02-deep-cards.js    ★ fully authored cards (stories + questions)
│   └── 03-engine.js        views, Bloom ladder, coach, paths, studio
└── dist/
    └── science-every-day-365.html    standalone build — give this to students
```

The two files marked ★ are the ones you will actually edit.

---

## Editing content

### Adding or correcting a roster entry — `js/01-roster.js`

Each day is one string with seven fields separated by `|`:

```
"Name|中文名|🇹🇼 Country|Years|Field|category|One-line contribution"
```

`R[7]` is July, and the array position is the date — so `R[7][0]` is July 1.
Keep each month's array at the correct length (31, 29, 31, 30, 31, 30, 31, 31,
30, 31, 30, 31).

Valid categories, which drive the colour coding and the learning paths:

| category     | meaning                    |
|--------------|----------------------------|
| `classic`    | canonical figure           |
| `women`      | women in science           |
| `asia`       | Asia & Taiwan              |
| `modern`     | living / contemporary      |
| `overlooked` | uncredited or marginalised |
| `team`       | collective or institution  |
| `event`      | discovery, mission, treaty |
| `ethics`     | ethics case study          |

### Upgrading a day to a full card — `js/02-deep-cards.js`

Add an entry keyed `'month-day'`. Anything you add here replaces the
auto-scaffold for that day:

```js
DEEP['3-14'] = {
  kw: [['keyword','中文']],
  story: { A2: '...', B1: '...', B2: '...' },
  quote: { text: '...', tag: 'verified', tagLabel: 'Verified 已查證' },
  life: 'One sentence connecting this to a student\u2019s day.',
  bloom: {
    remember:   { q: '...', opts: ['a','b','c','d'], correct: 0 },
    understand: { q: '...', opts: [...], correct: 0 },
    apply:      { q: '...', opts: [...], correct: 0 },
    analyze:    { q: '...', opts: [...], correct: 0 },
    evaluate:   { q: '...', stances: ['Yes','No','Depends'], starter: '...' },
    create:     { q: '...', starter: '...' }
  }
};
```

Quote tags must be one of `verified`, `attributed`, or `paraphrased` — never
guess. Misattributed quotations are the single most common error in this genre.

Any Bloom level may be either a multiple-choice item (supply `opts` + `correct`)
or an open response (supply `starter`, optionally `stances`). Levels 5 and 6
should normally stay open — see the pedagogy note below.

---

## How un-authored days behave

14 of 366 days are fully authored. The rest are **not broken** — they show:

- the verified roster facts (name, place, dates, field, contribution)
- an honest "story not yet written" notice
- a working Bloom ladder anyway

The auto-generated Remember question builds its wrong answers from *other real
scientists' contributions* drawn from the roster, so it is factually sound
rather than invented. Levels 2–6 become open-response prompts.

Writing the missing cards is designed to be the coursework, not the obstacle.
The in-app **Studio** tab lets students draft A2/B1/B2 versions of any day and
export them as JSON, which you can paste into `02-deep-cards.js`.

---

## Pedagogy notes

**The coach never scores.** Open responses receive language scaffolding only —
"add the word *because*", "add one clause beginning *Although…*". It detects
reasoning connectives, hedging, and concrete examples, and always ends by
directing the student to a partner or teacher. Automated marking of Evaluate and
Create would defeat the purpose of having those levels.

**No lone geniuses.** Authored cards name collaborators, predecessors and
institutions, and say plainly when someone was uncredited. Several Analyze
questions are built specifically to surface this.

**Categories are spread, not segregated.** Women, Asian and overlooked figures
appear in all twelve months rather than being confined to one. The Paths tab
lets you pull any theme into a single week when you want to teach it that way.

**Card collection unlocks at 3 of 6 levels**, so students can succeed without
completing every level — but the points are weighted heavily toward Evaluate
(35) and Create (50).

---

## Known limitations

- **Progress is not saved.** State lives in memory and resets on refresh. Adding
  persistence needs a backend, or `localStorage` if you host it yourself.
- **The roster is a curated draft.** 366 entries of dates and attributions were
  drafted rapidly. The structure and framing are sound, but a handful of dates
  or characterisations will need checking before classroom use. Treat it as a
  first draft by a well-read colleague, not a verified database.
- **No teacher dashboard yet.** There is no way to assign a day to a class or
  read student responses centrally.
- **Weekday alignment is approximate.** The month grid uses a fixed 2026-style
  layout rather than real calendar maths.

---

## Possible next steps

1. Verify the roster (a research assistant could do this in about a week).
2. Author the remaining cards — or have students do it, for credit.
3. Add `localStorage` persistence so streaks survive a refresh.
4. Build the teacher dashboard: assign, monitor, read responses, feature the best.
5. Wire the coach to a real language model for genuine formative feedback on
   Evaluate and Create — keeping the no-score rule.

---

*Built for 廖宜虹 (Cathy Liao), National Pingtung University.*
