/* Science Every Day 365 — DEEP-AUTHORED CARDS
   Hand-written A2/B1/B2 stories + custom Bloom questions.
   Key = "month-day", e.g. '7-1' = July 1.
   Add a new entry here and that day automatically upgrades from
   auto-scaffold to a fully authored card. */
/* ============================================================
   DEEP-AUTHORED DAYS — hand-written stories + Bloom questions.
   Key = "month-day". Every month has at least one.
   All other days run on the auto-scaffold engine.
   ============================================================ */
const DEEP={};

DEEP['1-1']={
 kw:[['gravity','重力'],['motion','運動'],['orbit','軌道'],['law','定律']],
 story:{
  A2:"Isaac Newton was an English scientist. He asked a simple question: why do things fall down? He said that everything pulls on everything else. This pull is called gravity. The same pull makes an apple fall and keeps the Moon going around the Earth. He also wrote three rules about how things move.",
  B1:"Isaac Newton asked why an apple falls to the ground while the Moon stays in the sky. His answer was that both are doing the same thing: every object pulls on every other object, and that pull is gravity. He also wrote three laws describing how forces change motion. Together these ideas explained the movement of falling objects and orbiting planets with a single set of rules — something no one had managed before.",
  B2:"Newton's achievement was one of unification. Before him, the heavens and the Earth were treated as separate domains with separate rules; he showed that a falling apple and an orbiting Moon obey the same mathematical law of gravitation. His three laws of motion, combined with the calculus he helped invent, turned physics into a predictive science. It is worth noting that he built on Kepler, Galileo and Hooke, and that he was capable of fierce disputes over credit — the mythology of solitary genius flattens a more contested history."
 },
 quote:{text:"If I have seen further, it is by standing on the shoulders of giants.", tag:'verified', tagLabel:'Verified 已查證'},
 life:"Every satellite that carries your phone signal, and every rocket launch schedule, is calculated using Newton's laws.",
 bloom:{
  remember:{q:"What did Newton say makes an apple fall and the Moon orbit?",
   opts:["The same force — gravity","Two completely different forces","Magnetism only","The wind"],correct:0},
  understand:{q:"Which sentence explains Newton's big idea most simply?",
   opts:["Heaven and Earth follow the same rules of motion.","Only objects on Earth obey physical laws.","The Moon is pushed by sunlight.","Apples fall because they are heavy and the Moon is light."],correct:0},
  apply:{q:"Where are Newton's laws used today?",
   opts:["Calculating satellite and rocket paths","Choosing colours for a website","Translating languages","Baking bread"],correct:0},
  analyze:{q:"The B2 text says the 'solitary genius' story is misleading. Which detail supports that?",
   opts:["He built on Kepler, Galileo and Hooke and argued over credit.","He was born in England.","He wrote three laws.","He studied gravity."],correct:0},
  evaluate:{q:"Newton's quote credits 'giants' before him, yet he fought bitterly over priority. Is the quote honest humility or good public relations? Take a stance and defend it in 1–3 English sentences.",
   stances:["Genuine humility","Public relations","Both at once"],starter:'I think the quote is ___ because…'},
  create:{q:"Write a 2–3 sentence explanation of gravity for a curious 8-year-old, without using the word 'force'.",
   starter:'Try starting with something they can see: "Everything in the universe is a little bit sticky…"'}
 }};

DEEP['2-4']={
 kw:[['radioactivity','放射性'],['radium','鐳'],['element','元素'],['Nobel Prize','諾貝爾獎']],
 story:{
  A2:"Marie Curie was a scientist from Poland who worked in France. She studied strange rays that come out of some rocks. She found two new elements and named one of them radium. She won the Nobel Prize two times. She was the first woman to win it. Her work helps doctors treat cancer today.",
  B1:"Marie Curie studied strange rays given off by certain minerals. Because these rays were new to science, she gave them a name: radioactivity. Working in a cold, leaking shed with her husband Pierre, she discovered two elements, polonium and radium. Her research later helped doctors use radiation to treat cancer, and she became the first person to win a Nobel Prize in two different sciences.",
  B2:"Marie Curie transformed physics and chemistry by investigating the radiation emitted by uranium, coining the term radioactivity. Working in poor conditions and facing barriers as a woman and an immigrant, she isolated polonium and radium. Yet her story is not one of a lone genius: Pierre Curie was her research partner, and her results built directly on Henri Becquerel's findings. Her discoveries reshaped medicine, though the same radiation that made her famous ultimately damaged her health and killed her."
 },
 quote:{text:"Nothing in life is to be feared, it is only to be understood.", tag:'attributed', tagLabel:'Attributed 常被引用'},
 life:"The radiation therapy used in hospitals to treat some cancers traces directly back to Curie's work on radium.",
 bloom:{
  remember:{q:"Which two elements did Marie Curie discover?",
   opts:["Polonium and radium","Oxygen and helium","Uranium and gold","Sodium and iron"],correct:0},
  understand:{q:"Which sentence best explains 'radioactivity' to a 10-year-old?",
   opts:["Some materials give off invisible energy rays all by themselves.","It is a machine that makes electricity for cities.","It is a type of rock found only in Poland.","It is a medicine you drink when you are sick."],correct:0},
  apply:{q:"Where do you meet Curie's work in everyday life?",
   opts:["A hospital X-ray or cancer radiation therapy","A refrigerator keeping milk cold","A phone charging overnight","A bicycle going downhill"],correct:0},
  analyze:{q:"The story says Curie was 'not a lone genius'. Which detail best supports that?",
   opts:["Her work built on Becquerel's findings and Pierre was her partner.","She won two Nobel Prizes.","She worked in a cold shed.","She coined the word radioactivity."],correct:0},
  evaluate:{q:"Curie's radium research led to cancer treatment but also killed her. Was the trade-off worth it? Take a stance and give 1–3 sentences of reasoning in English.",
   stances:["Worth it","Not worth it","It's complicated"],starter:'I think it was ___ because…'},
  create:{q:"Write a 2–3 sentence social-media post introducing Marie Curie to teenagers. Start with a hook.",
   starter:'Try starting with: "Imagine glowing rocks that could…"'}
 }};

DEEP['2-25']={
 kw:[['parity','宇稱'],['beta decay','β衰變'],['symmetry','對稱'],['experiment','實驗']],
 story:{
  A2:"Chien-Shiung Wu was a physicist. She was very good at doing careful experiments. Two other scientists had an idea about how nature works, but they could not test it. Wu did the test. She showed their idea was right. They won the Nobel Prize. She did not.",
  B1:"Chien-Shiung Wu became one of the greatest experimental physicists of her time. Two theorists, Lee and Yang, suggested that nature might not be perfectly symmetric — that left and right could behave differently at the smallest scale. Their idea needed proof. Wu designed an extremely careful experiment with supercooled cobalt atoms and showed they were right. Lee and Yang won the Nobel Prize; Wu, whose experiment made it possible, was left out.",
  B2:"Chien-Shiung Wu was a master of experimental precision at a time when few women led physics laboratories. When theorists Lee and Yang proposed that parity — the assumption that nature treats left and right identically — might be violated, only an experiment could decide. Wu's meticulous work with supercooled cobalt-60 confirmed the violation, overturning a law physicists had taken for granted. Lee and Yang received the 1957 Nobel Prize; Wu's foundational role went unrecognised by the committee, and her case is now a standard example in discussions of how scientific credit is assigned."
 },
 quote:{text:"It is shameful that there are so few women in science.", tag:'attributed', tagLabel:'Attributed 常被引用'},
 life:"Every particle physics detector built since 1957 assumes the left-right asymmetry Wu was the first to demonstrate.",
 bloom:{
  remember:{q:"What did Wu's famous experiment prove?",
   opts:["That parity (left–right symmetry) can be violated","That the Earth orbits the Sun","That radium glows in the dark","That light is a wave"],correct:0},
  understand:{q:"Which is the simplest way to explain her result?",
   opts:["Nature does not always treat 'left' and 'right' the same way.","Cold makes all atoms stop moving forever.","Physics only works inside a laboratory.","Metals become magnets when heated."],correct:0},
  apply:{q:"Wu was famous for being extremely careful. In which everyday situation does that same skill matter most?",
   opts:["A pharmacist measuring an exact medicine dose","Choosing a colour to paint a wall","Picking a song to play","Deciding what to eat for lunch"],correct:0},
  analyze:{q:"Why is Wu a standard example in discussions of scientific credit?",
   opts:["Her experiment made the discovery possible, but only the theorists won the Nobel.","She never published her results.","She refused to do the experiment.","She worked with no theoretical input at all."],correct:0},
  evaluate:{q:"The Nobel went to the theorists, not to Wu who ran the decisive experiment. Was that fair? Take a stance and explain in 1–3 English sentences.",
   stances:["Fair","Unfair","Depends"],starter:'I believe this was ___ because…'},
  create:{q:"Write a one-line news headline announcing Wu's 1957 result for a general audience.",
   starter:'Headlines are short and punchy — try: "Physicist proves nature has a…"'}
 }};

DEEP['3-1']={
 kw:[['relativity','相對論'],['spacetime','時空'],['energy','能量'],['light speed','光速']],
 story:{
  A2:"Albert Einstein was a scientist born in Germany. He worked in a patent office and thought about light. He said that time can run faster or slower. He also said that mass and energy are the same thing. His famous equation is E = mc². Many people think he is the most famous scientist ever.",
  B1:"Albert Einstein asked what the world would look like if you rode alongside a beam of light. His answer, special relativity, showed that time and distance are not fixed: they depend on how you are moving. Later, general relativity described gravity not as a pull but as a bending of space and time itself. His equation E = mc² revealed that mass and energy are two forms of the same thing — an idea with consequences he could not have predicted.",
  B2:"Einstein's work dismantled the Newtonian assumption of absolute space and time. Special relativity established that the speed of light is constant for all observers, forcing simultaneity itself to become relative. General relativity then reinterpreted gravity as the curvature of spacetime by mass and energy, a prediction confirmed by starlight bending during a 1919 eclipse. His mass–energy equivalence later underpinned nuclear physics, and Einstein — a lifelong pacifist — signed a letter urging the US to build an atomic weapon, a decision he described afterwards as his greatest regret."
 },
 quote:{text:"Imagination is more important than knowledge.", tag:'attributed', tagLabel:'Attributed 常被引用'},
 life:"Your phone's GPS would drift by kilometres each day if the satellites did not correct for relativity.",
 bloom:{
  remember:{q:"What does Einstein's equation E = mc² say?",
   opts:["Mass and energy are two forms of the same thing","Light always travels in circles","Gravity does not exist","Time is exactly the same for everyone"],correct:0},
  understand:{q:"How does general relativity describe gravity?",
   opts:["As mass and energy bending space and time","As a magnetic pull between metals","As air pushing objects down","As a chemical reaction"],correct:0},
  apply:{q:"Which everyday technology must correct for relativity?",
   opts:["GPS navigation on your phone","A mechanical wristwatch","A bicycle bell","A paper map"],correct:0},
  analyze:{q:"What does the B2 text suggest about the relationship between discovery and responsibility?",
   opts:["A pacifist's physics enabled a weapon he later regretted supporting.","Scientific ideas never affect politics.","Einstein designed the atomic bomb himself.","Relativity has no practical uses."],correct:0},
  evaluate:{q:"Should a scientist be held responsible for how their discoveries are later used? Take a stance and argue it in 1–3 English sentences.",
   stances:["Yes, responsible","No, not responsible","Partly responsible"],starter:'I think scientists are ___ because…'},
  create:{q:"Design an analogy that explains 'space bends around heavy objects' using something in a classroom.",
   starter:'Think about fabric, trampolines, mattresses — or invent something better.'}
 }};

DEEP['4-5']={
 kw:[['ocean floor','海床'],['mid-ocean ridge','中洋脊'],['plate tectonics','板塊構造'],['map','地圖']],
 story:{
  A2:"Marie Tharp was an American scientist. She made maps of the bottom of the sea. Women were not allowed on the research ships, so she stayed in the office. She drew the numbers by hand. She found a huge mountain range under the ocean with a valley in the middle. At first, people said she was wrong.",
  B1:"Marie Tharp was not allowed on the research ships because she was a woman, so she worked from the numbers other people brought back. Drawing them by hand, she revealed something no one expected: a chain of mountains running down the middle of the Atlantic, split by a deep valley. That valley was evidence that the seafloor was spreading apart. Her colleague first dismissed the idea as 'girl talk' — but the map was right, and it helped prove plate tectonics.",
  B2:"Marie Tharp spent two decades converting sonar soundings into the first physiographic maps of the ocean floor, work she performed from shore because women were barred from the research vessels. Her hand-drawn profiles revealed a continuous mid-ocean ridge system bisected by a rift valley — an observation that supported seafloor spreading and, with it, the then-controversial theory of continental drift. Her collaborator initially rejected the interpretation. Tharp's maps were eventually published under joint authorship, and her recognition arrived largely in the final years of her life."
 },
 quote:{text:"I was so busy making maps I let them argue.", tag:'attributed', tagLabel:'Attributed 常被引用'},
 life:"Undersea internet cables — carrying almost all international data — are routed using maps descended from Tharp's work.",
 bloom:{
  remember:{q:"What did Marie Tharp discover on the ocean floor?",
   opts:["A mid-ocean mountain ridge split by a rift valley","A sunken continent","A new species of whale","An underwater volcano in Taiwan"],correct:0},
  understand:{q:"Why did she work from shore instead of at sea?",
   opts:["Women were not allowed on the research ships.","She was afraid of water.","The ships had no space for equipment.","She preferred computers."],correct:0},
  apply:{q:"Where does her ocean-floor mapping matter today?",
   opts:["Routing the undersea cables that carry the internet","Deciding train timetables","Predicting stock prices","Designing phone screens"],correct:0},
  analyze:{q:"What does the 'girl talk' dismissal reveal about how evidence is received?",
   opts:["Who presents evidence can affect whether it is believed.","Data always convinces people immediately.","Maps are less reliable than opinions.","Her measurements were actually wrong."],correct:0},
  evaluate:{q:"Tharp's recognition came near the end of her life. Whose responsibility is it to correct historical credit — universities, textbooks, or the public? Argue in 1–3 English sentences.",
   stances:["Institutions","Educators & textbooks","Everyone"],starter:'I think the responsibility lies with ___ because…'},
  create:{q:"Write a 30-second museum audio-guide script for visitors standing in front of Tharp's map.",
   starter:'Audio guides speak directly: "Look closely at the line running down the middle…"'}
 }};

DEEP['5-1']={
 kw:[['evolution','演化'],['natural selection','天擇'],['species','物種'],['adaptation','適應']],
 story:{
  A2:"Charles Darwin travelled around the world on a ship called the Beagle. He looked at many animals and plants. He saw that babies are a little different from their parents. Animals with useful differences live longer and have more babies. Slowly, over a very long time, species change. This idea is called evolution by natural selection.",
  B1:"On a five-year voyage, Charles Darwin collected finches, fossils and beetles, and noticed patterns that puzzled him. His explanation was simple but powerful: offspring vary, more are born than can survive, and those with helpful variations leave more descendants. Repeated over immense time, this process — natural selection — can produce new species. He delayed publishing for twenty years, and only went to press when Alfred Russel Wallace independently arrived at the same idea.",
  B2:"Darwin's contribution was mechanistic rather than merely descriptive: evolution had been proposed before, but he supplied a process. Variation, inheritance, overproduction and differential survival together explain adaptation without appeal to design. He assembled an unusually broad evidential base — domestication, biogeography, embryology, the fossil record — and anticipated objections in print. He also withheld publication for two decades, aware of the theological storm ahead, and moved only when Wallace's manuscript arrived. The joint 1858 presentation is a rare case of a priority dispute resolved gracefully."
 },
 quote:{text:"It is not the strongest of the species that survives, but the most adaptable.", tag:'paraphrased', tagLabel:'Paraphrased 概念改寫 — 常被誤植'},
 life:"Antibiotic resistance in hospitals is natural selection happening fast enough to watch within a single patient.",
 bloom:{
  remember:{q:"What is 'natural selection'?",
   opts:["Individuals with helpful variations leave more offspring","Animals choosing where to live","Humans breeding animals on purpose","Species changing instantly in one generation"],correct:0},
  understand:{q:"Which statement best summarises Darwin's specific contribution?",
   opts:["He supplied a mechanism for how species change.","He was the first to suggest species change at all.","He proved the Earth is old.","He discovered DNA."],correct:0},
  apply:{q:"Where can you see natural selection acting quickly today?",
   opts:["Bacteria becoming resistant to antibiotics","Rocks eroding on a beach","Ice melting in a glass","A car rusting"],correct:0},
  analyze:{q:"Why is the famous 'most adaptable' quote tagged as paraphrased rather than verified?",
   opts:["It is widely attributed to Darwin but does not appear in his writings.","It was written in Latin.","Darwin said it twice.","It comes from Wallace's diary."],correct:0},
  evaluate:{q:"Darwin waited twenty years, partly fearing public reaction. Is delaying publication for social reasons ever defensible for a scientist? Argue in 1–3 English sentences.",
   stances:["Defensible","Not defensible","Depends on the stakes"],starter:'I think delaying publication is ___ because…'},
  create:{q:"Explain natural selection in three sentences using ONLY an example from your own country or campus.",
   starter:'Local examples land harder than finches — think insects, plants, stray animals, or bacteria.'}
 }};

DEEP['6-12']={
 kw:[['consent','知情同意'],['HeLa cells','海拉細胞'],['cell line','細胞株'],['research ethics','研究倫理']],
 story:{
  A2:"Henrietta Lacks was a young mother in the United States. She was very sick with cancer. Doctors took some of her cells without asking her. Those cells did something strange: they kept living and growing. Scientists still use them today. Her family did not know for many years.",
  B1:"In 1951, Henrietta Lacks went to hospital with cancer. A doctor took a sample of her tumour without asking her permission — normal practice at the time. Unlike other cells, hers kept dividing in the laboratory, and they still do. Called HeLa cells, they helped test the polio vaccine and appear in tens of thousands of studies. Henrietta died at 31, and her family learned about the cells only twenty years later, while companies were already selling them.",
  B2:"The HeLa cell line, derived from Henrietta Lacks's cervical tumour in 1951, is the most widely used human cell line in biomedical research. It was established without her knowledge or consent, in an era when tissue taken during treatment carried no requirement of permission. HeLa underpinned polio vaccine testing, cancer research and countless protocols; meanwhile her descendants lacked health insurance and were not informed for two decades. The case reshaped debates on consent, tissue ownership, racial inequity in medicine, and whether benefit-sharing is owed to donors — questions that remain only partly resolved."
 },
 quote:{text:"Her cells outlived her by generations; her name took decades to catch up.", tag:'paraphrased', tagLabel:'Paraphrased 概念改寫'},
 life:"If you were vaccinated against polio, or take almost any modern medicine, HeLa cells were part of the testing chain.",
 bloom:{
  remember:{q:"How were Henrietta Lacks's cells obtained?",
   opts:["Taken during treatment without her knowledge or consent","Donated by her in writing","Bought from her family","Created artificially in a laboratory"],correct:0},
  understand:{q:"Why were her cells so scientifically valuable?",
   opts:["They kept dividing indefinitely in the laboratory.","They cured cancer directly.","They were the first cells ever seen.","They could be eaten safely."],correct:0},
  apply:{q:"How does this story connect to modern hospital paperwork?",
   opts:["It is part of why you now sign informed consent forms.","It explains hospital parking fees.","It set the price of medicine.","It created the ambulance system."],correct:0},
  analyze:{q:"Which factors does the B2 text link together in this case?",
   opts:["Consent, tissue ownership, racial inequity and benefit-sharing","Only the speed of cell division","Only the polio vaccine","Only hospital funding"],correct:0},
  evaluate:{q:"Should families of tissue donors share in profits from discoveries made with those cells? Take a stance and argue it in 1–3 English sentences.",
   stances:["Yes, they should","No, they should not","A middle path"],starter:'I think donors and families ___ because…'},
  create:{q:"Write a short, respectful consent-form paragraph (2–3 sentences) explaining to a patient in plain English what may happen to their tissue sample.",
   starter:'Plain English means no jargon and no hiding — say what will happen and what choice they have.'}
 }};

DEEP['7-1']={
 kw:[['microbe','微生物'],['germ theory','細菌學說'],['pasteurization','巴氏消毒'],['vaccine','疫苗']],
 story:{
  A2:"Louis Pasteur was a French scientist. He showed that very small living things — germs — can make food go bad and make people sick. He found that heating milk a little kills the germs. This idea is called pasteurization. He also helped make some of the first vaccines.",
  B1:"Louis Pasteur helped prove germ theory — the idea that invisible microbes, not bad air, cause many diseases and make food spoil. To keep drinks safe, he showed that gently heating them killed harmful microbes without ruining the taste. This process, now called pasteurization, is still used on milk today. He also developed early vaccines against anthrax and rabies, saving countless lives.",
  B2:"Louis Pasteur was central to establishing germ theory, demonstrating that microorganisms — not spontaneous generation or foul air — cause fermentation, spoilage and infectious disease. His swan-neck flask experiments were models of controlled reasoning. To protect France's wine and dairy industries he devised gentle heat treatment, and he pioneered vaccines against anthrax and rabies. His breakthroughs drew on a wider community of microbiologists and on strong commercial pressure, and his notebooks later revealed he took clinical risks his public accounts did not mention."
 },
 quote:{text:"Chance favors the prepared mind.", tag:'verified', tagLabel:'Verified 已查證'},
 life:"The milk in your refrigerator is safe to drink largely because it was pasteurized — heated exactly the way Pasteur described.",
 bloom:{
  remember:{q:"What does 'pasteurization' do?",
   opts:["Gently heats drinks to kill harmful microbes","Freezes food to make it last","Adds sugar to milk","Colours drinks to look fresh"],correct:0},
  understand:{q:"Which statement best summarises germ theory?",
   opts:["Tiny living microbes cause many diseases and food spoilage.","Bad smells alone cause all illness.","Food never goes bad if kept in the dark.","Only large animals can spread sickness."],correct:0},
  apply:{q:"How is Pasteur's work connected to your refrigerator?",
   opts:["The milk inside was pasteurized so microbes won't make you sick.","It keeps the milk frozen solid.","It makes the milk taste sweeter.","It turns milk into cheese automatically."],correct:0},
  analyze:{q:"Which part of the B2 text complicates the heroic version of Pasteur?",
   opts:["Commercial pressure shaped his work and his notebooks show undisclosed risks.","He heated milk gently.","He was born in France.","He made a rabies vaccine."],correct:0},
  evaluate:{q:"Pasteur tested his rabies vaccine on a boy before it was fully proven safe. Judge that decision by today's ethics in 1–3 English sentences.",
   stances:["Justified","Not justified","Hard to judge"],starter:"By today's standards, this was ___ because…"},
  create:{q:"Design a simple metaphor that explains 'germs cause disease' to a young child.",
   starter:'Try: "Germs are like tiny…" — then make it specific enough to picture.'}
 }};

DEEP['8-1']={
 kw:[['DNA','去氧核醣核酸'],['X-ray diffraction','X光繞射'],['double helix','雙螺旋'],['Photo 51','51號照片']],
 story:{
  A2:"Rosalind Franklin was a British scientist. She used X-rays to take pictures of DNA, the code inside our cells. One picture, called Photo 51, was very important. It helped show that DNA has a twisted shape like a ladder. She did not get much credit while she was alive.",
  B1:"Rosalind Franklin was an expert at X-ray diffraction, a way of photographing the shape of tiny molecules. Her clear image of DNA, known as Photo 51, gave the strongest evidence that DNA is a double helix — two strands twisted together. Watson and Crick used her data to build their famous model, but Franklin received little recognition at the time, partly because she was a woman in a male-dominated field.",
  B2:"Rosalind Franklin's expertise in X-ray crystallography produced Photo 51, the diffraction image that revealed DNA's helical geometry. Watson and Crick relied on her data — shown to them without her knowledge — to construct their double-helix model, for which they and Wilkins later received the Nobel Prize. Franklin died of ovarian cancer at 37, before any Nobel could have been awarded to her, and her contribution was minimised in early published accounts. Her case is now a landmark in discussions of gender, credit and research ethics."
 },
 quote:{text:"Science and everyday life cannot and should not be separated.", tag:'verified', tagLabel:'Verified 已查證'},
 life:"DNA tests used in medicine, ancestry kits and crime labs all depend on the double-helix structure Franklin's images helped reveal.",
 bloom:{
  remember:{q:"What did 'Photo 51' show?",
   opts:["Strong evidence that DNA is a double helix","A map of the human brain","The surface of the Moon","A new kind of vaccine"],correct:0},
  understand:{q:"What did X-ray diffraction let Franklin do?",
   opts:["Photograph the shape of tiny molecules like DNA","Cure diseases directly","Make DNA glow in the dark","Count cells one by one"],correct:0},
  apply:{q:"Franklin's discovery underlies which modern technology?",
   opts:["DNA ancestry and forensic testing","Weather forecasting","Wireless charging","Solar panels"],correct:0},
  analyze:{q:"Why is Franklin a key example in research ethics discussions?",
   opts:["Her data was shown to Watson and Crick without her knowledge and her role was minimised.","She refused to share any of her work.","She invented the Nobel Prize.","She worked on the Moon landing."],correct:0},
  evaluate:{q:"Watson and Crick used Franklin's data without her consent. Judge this by today's research ethics in 1–3 English sentences.",
   stances:["Unacceptable","Understandable for the era","Complicated"],starter:"By today's standards, this was ___ because…"},
  create:{q:"Write a short museum plaque (2–3 sentences) that gives Franklin the credit she deserves.",
   starter:'Plaques are factual but warm — start with her name and what she revealed.'}
 }};

DEEP['9-1']={
 kw:[['algorithm','演算法'],['computing','計算'],['program','程式'],['symbol','符號']],
 story:{
  A2:"Ada Lovelace lived in England almost 200 years ago. Her friend Charles Babbage designed a big machine that could do maths. Ada wrote notes about it. In her notes she wrote the first computer program. She also said the machine could work with music and pictures, not just numbers. She was right.",
  B1:"Ada Lovelace was asked to translate an article about Charles Babbage's proposed calculating engine. She added her own notes, which ended up three times longer than the original. In them she wrote a step-by-step method for the machine to compute a sequence of numbers — now considered the first published algorithm. More importantly, she saw further than Babbage: if numbers could represent musical notes or letters, the machine could compose and write, not just calculate.",
  B2:"Ada Lovelace's 1843 notes on Menabrea's paper contain both the first published algorithm intended for machine execution and a conceptual leap that Babbage himself did not make: the recognition that a general-purpose engine manipulates symbols, not merely quantities, and could therefore operate on music or language. She also cautioned that the machine could only do what it was ordered to do — a remark still cited in debates about machine creativity. Her contribution has been alternately inflated and dismissed, and the historiographical argument over her role is itself a useful case study in how credit is contested."
 },
 quote:{text:"The Analytical Engine has no pretensions whatever to originate anything.", tag:'verified', tagLabel:'Verified 已查證'},
 life:"Every app on your phone rests on Lovelace's insight that numbers can stand for anything — sound, images, or text.",
 bloom:{
  remember:{q:"What did Ada Lovelace write in her notes?",
   opts:["The first published algorithm for a machine","The first novel about robots","A new system of arithmetic","A design for the telephone"],correct:0},
  understand:{q:"What was her leap beyond Babbage's own thinking?",
   opts:["That the machine could handle symbols like music and letters, not just numbers","That machines should be smaller","That maths is difficult","That the engine should be steam-powered"],correct:0},
  apply:{q:"Where do you see her insight in daily life?",
   opts:["Music, photos and text all stored as numbers on your phone","Water pipes in a building","The taste of food","The colour of the sky"],correct:0},
  analyze:{q:"The B2 text says her legacy is 'contested'. What does that mean here?",
   opts:["Historians disagree about how much of the work was hers.","Her notes were lost.","She never published anything.","Babbage denied knowing her."],correct:0},
  evaluate:{q:"Lovelace wrote that a machine cannot 'originate anything'. Given today's AI, was she right? Take a stance and argue it in 1–3 English sentences.",
   stances:["She was right","She was wrong","Still an open question"],starter:'I think Lovelace was ___ because…'},
  create:{q:"Write a 3-sentence pitch for a film about Ada Lovelace aimed at teenagers.",
   starter:'A pitch names the hook, the tension and why it matters now.'}
 }};

DEEP['9-5']={
 kw:[['orbit','軌道'],['trajectory','軌跡'],['segregation','種族隔離'],['computer','計算員']],
 story:{
  A2:"Katherine Johnson was a mathematician in the United States. She worked for NASA. She did the maths to send astronauts into space and bring them home safely. She was a Black woman, and at that time she had to use a different bathroom and eat in a different room. John Glenn would not fly until she checked the numbers.",
  B1:"Katherine Johnson calculated flight paths for America's first crewed space missions. She worked in a segregated NASA where Black women mathematicians — called 'computers' — sat in a separate building and used separate facilities. When electronic computers first produced the orbital numbers for John Glenn's flight, Glenn reportedly refused to fly until Johnson had checked them by hand. She later worked on Apollo and stayed at NASA for over three decades.",
  B2:"Katherine Johnson's analytic geometry underpinned the trajectory calculations for Alan Shepard's suborbital flight, John Glenn's orbital mission and the Apollo lunar programme. She performed this work within a legally segregated institution, where Black women in the West Computing group faced separate facilities and restricted advancement. Glenn's request that she personally verify the electronic computer's output has become emblematic — not merely of individual brilliance, but of how institutional racism concealed capability that the mission itself depended on. Her public recognition came more than fifty years later."
 },
 quote:{text:"Get the girl to check the numbers.", tag:'attributed', tagLabel:'Attributed 常被引用'},
 life:"The orbital mechanics she calculated by hand still govern every satellite launch scheduled today.",
 bloom:{
  remember:{q:"What did Katherine Johnson calculate for NASA?",
   opts:["Flight paths and orbital trajectories","Rocket fuel prices","Astronaut meal plans","Radio frequencies"],correct:0},
  understand:{q:"Why is the John Glenn story significant?",
   opts:["An astronaut trusted her hand calculations over the electronic computer.","She refused to let him fly.","She designed the rocket herself.","She was the first woman in space."],correct:0},
  apply:{q:"Where is her kind of orbital mathematics used today?",
   opts:["Planning satellite and rocket launches","Designing furniture","Setting exam timetables","Writing song lyrics"],correct:0},
  analyze:{q:"What does the B2 text argue the Glenn story really illustrates?",
   opts:["How institutional racism hid capability the mission depended on","That electronic computers were useless","That astronauts disliked mathematics","That NASA had no rules"],correct:0},
  evaluate:{q:"Johnson was recognised publicly only decades later, largely after a book and film. Is popular media a good way to correct historical credit? Argue in 1–3 English sentences.",
   stances:["Yes, it works","No, it distorts","Useful but risky"],starter:'I think popular media is ___ for correcting credit because…'},
  create:{q:"Write a 30-second spoken introduction for Katherine Johnson at an awards ceremony.",
   starter:'Spoken introductions build: who she is, what she did, why the room should care.'}
 }};

DEEP['10-11']={
 kw:[['Cepheid variable','造父變星'],['distance','距離'],['luminosity','光度'],['galaxy','星系']],
 story:{
  A2:"Henrietta Swan Leavitt worked at Harvard. Her job was to look at photographs of stars. She was paid very little. She found that some stars get bright and dim in a pattern. The slower the pattern, the brighter the star really is. This let other scientists measure how far away stars are.",
  B1:"Henrietta Swan Leavitt was hired as a 'computer' at Harvard Observatory, examining photographic plates for a low wage and without the freedom to choose her own research. Studying variable stars, she found a precise relationship: the longer a star takes to pulse, the brighter it truly is. Comparing true brightness with apparent brightness gives distance. This became astronomy's measuring stick — the tool Edwin Hubble later used to show the universe is expanding.",
  B2:"Leavitt's period–luminosity relation for Cepheid variables supplied astronomy with its first reliable standard candle, converting the intractable problem of cosmic distance into a measurable quantity. Working as a poorly paid assistant with restricted research autonomy, and deaf from early adulthood, she published the relation in 1912. Hubble's demonstration that spiral nebulae lie outside the Milky Way, and his subsequent expansion law, rest directly upon it. A Nobel nomination was prepared in 1925, four years after her death; the prize is not awarded posthumously."
 },
 quote:{text:"A straight line can readily be drawn among each of the two series of points.", tag:'verified', tagLabel:'Verified 已查證'},
 life:"Every statement about how far away a galaxy is — including the age of the universe — traces back to Leavitt's ruler.",
 bloom:{
  remember:{q:"What relationship did Leavitt discover?",
   opts:["The slower a star pulses, the brighter it truly is","Stars are all the same distance away","Bigger stars are always closer","Stars pulse only in winter"],correct:0},
  understand:{q:"Why was this so useful?",
   opts:["Comparing true and apparent brightness gives distance.","It proved stars are made of hydrogen.","It showed the Sun will explode.","It measured the temperature of space."],correct:0},
  apply:{q:"What modern claim depends on her work?",
   opts:["Estimates of how far away galaxies are and how old the universe is","Weather forecasts for next week","The length of a year on Earth","Tide tables"],correct:0},
  analyze:{q:"Which conditions of her employment does the B2 text highlight?",
   opts:["Low pay, restricted research autonomy, and no posthumous Nobel possible","She led the observatory","She chose all her own projects","She was paid more than her colleagues"],correct:0},
  evaluate:{q:"The Nobel is never awarded posthumously. Should that rule change for cases like Leavitt's? Argue your stance in 1–3 English sentences.",
   stances:["Change the rule","Keep the rule","Create another honour"],starter:'I think the rule should ___ because…'},
  create:{q:"Explain a 'standard candle' in three sentences using an everyday object as the analogy.",
   starter:'Think about how you judge distance at night — street lamps, car headlights, phone torches.'}
 }};

DEEP['11-12']={
 kw:[['semiconductor','半導體'],['foundry','晶圓代工'],['supply chain','供應鏈'],['ecosystem','生態系']],
 story:{
  A2:"This is a team story. Many engineers in Taiwan worked together to make computer chips. Chips are tiny parts inside phones and computers. Taiwan became one of the best places in the world to make them. This was not one hero. It was thousands of people working together for many years.",
  B1:"Instead of one scientist, today is about a team. From the 1980s, Taiwanese engineers, government planners and returning overseas researchers built a semiconductor industry from almost nothing. The 'foundry' model — factories that manufacture chips designed by other companies — turned Taiwan into a global leader. Today many of the world's most advanced chips, found in phones and cars, are made on the island. It is a story of collective effort, not a single genius.",
  B2:"Taiwan's rise as a semiconductor powerhouse illustrates how modern breakthroughs are systemic rather than individual. From the 1980s, a combination of state industrial strategy, returning overseas-trained engineers, and the pure-play foundry model reshaped global technology. Thousands of specialists in materials, optics, metrology and manufacturing pushed transistors to ever smaller scales, supported by an unusually dense supplier network. The result — an island central to the world's chip supply chain — is a case study in infrastructure, accumulated tacit skill, and the social conditions that make discovery possible, as well as a live question in geopolitics."
 },
 quote:{text:"No single person builds a chip; a whole ecosystem does.", tag:'paraphrased', tagLabel:'Paraphrased 概念改寫'},
 life:"The phone or laptop you are reading this on almost certainly contains chips connected to Taiwan's semiconductor ecosystem.",
 bloom:{
  remember:{q:"What made Taiwan a global technology leader?",
   opts:["Building an advanced semiconductor industry","Growing the most rice","Making the tallest buildings","Discovering a new ocean"],correct:0},
  understand:{q:"What is a chip 'foundry'?",
   opts:["A factory that manufactures chips designed by other companies","A shop that sells phones","A school for engineers","A type of computer game"],correct:0},
  apply:{q:"How does this story connect to your daily life?",
   opts:["Your phone and laptop contain chips from this ecosystem.","It decides the weather each day.","It grows the food you eat.","It powers ocean tides."],correct:0},
  analyze:{q:"Why is this a 'collective' rather than a 'lone genius' story?",
   opts:["State strategy, returning engineers and dense supplier networks all played a part.","One inventor did everything alone.","It happened overnight by accident.","No teamwork was involved."],correct:0},
  evaluate:{q:"The world now depends heavily on one island for advanced chips. Is that concentration a strength or a risk? Argue in 1–3 English sentences.",
   stances:["Mostly a strength","Mostly a risk","Both at once"],starter:'I think this concentration is ___ because…'},
  create:{q:"Design a 'parallel world' scenario: \"If Taiwan had never built its chip industry, then…\" (2–3 sentences).",
   starter:'Imagine the ripple effects on phones, cars, hospitals and daily life.'}
 }};

DEEP['12-3']={
 kw:[['conscience','良知'],['disarmament','裁軍'],['responsibility','責任'],['Pugwash','帕格沃什']],
 story:{
  A2:"Joseph Rotblat was a physicist from Poland. He worked on the atomic bomb during the war. He joined because he was afraid Germany would build one first. When he learned Germany had stopped, he left the project. He was the only scientist who did. Later he won the Nobel Peace Prize.",
  B1:"Joseph Rotblat joined the Manhattan Project for one reason: he feared Nazi Germany would build an atomic bomb first. In late 1944, when it became clear Germany had abandoned its programme, his reason disappeared — so he left. He was the only scientist to walk away on grounds of conscience, and he was treated with suspicion for it. He spent the rest of his life on nuclear disarmament and medical physics, and shared the 1995 Nobel Peace Prize.",
  B2:"Rotblat's departure from Los Alamos in December 1944 is the clearest historical instance of a scientist withdrawing from a project on ethical grounds after his stated justification lapsed. He faced accusations of espionage and had his papers confiscated. He subsequently co-founded the Pugwash Conferences, which created a durable back-channel between Soviet and Western scientists throughout the Cold War, and he argued for a Hippocratic-style oath for scientists. His career poses the sharpest version of the question this month circles: what, concretely, does a researcher do when the work is proceeding and the reasons have changed?"
 },
 quote:{text:"Above all, remember your humanity.", tag:'verified', tagLabel:'Verified 已查證 (Russell–Einstein Manifesto)'},
 life:"Debates today about AI researchers resigning over safety concerns follow a path Rotblat walked first.",
 bloom:{
  remember:{q:"Why did Rotblat leave the Manhattan Project?",
   opts:["Germany had abandoned its bomb programme, so his reason was gone","He was fired for poor work","He wanted a better salary","He became too ill to continue"],correct:0},
  understand:{q:"What made his decision unusual?",
   opts:["He was the only scientist to leave on grounds of conscience.","He was the youngest person there.","He had never studied physics.","He told no one his reasons."],correct:0},
  apply:{q:"Which modern situation most resembles his choice?",
   opts:["A researcher resigning over safety concerns about their own project","A student changing university major","An engineer taking a holiday","A company changing its logo"],correct:0},
  analyze:{q:"What was the personal cost of his decision, according to the B2 text?",
   opts:["He was accused of espionage and had his papers confiscated.","He was immediately given a Nobel Prize.","He was promoted to project leader.","Nothing happened to him."],correct:0},
  evaluate:{q:"Is leaving a project the most effective form of protest, or does staying inside allow more influence? Take a stance and argue it in 1–3 English sentences.",
   stances:["Leaving is stronger","Staying is stronger","Depends on the situation"],starter:'I think ___ has more effect because…'},
  create:{q:"Draft three lines of an oath you think scientists should take before starting a project.",
   starter:'Oaths are short, concrete and testable — avoid vague words like "good" or "responsible".'}
 }};
